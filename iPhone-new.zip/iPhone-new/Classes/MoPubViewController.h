//
//  MoPubViewController.h
//  MoPub
//
//  Created by Nafis Jamal on 1/19/11.
//  Copyright 2011 Stanford. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MPAdView.h"
#import "MPInterstitialAdController.h"

@interface MoPubViewController : UIViewController <MPInterstitialAdControllerDelegate> {
}

@end

