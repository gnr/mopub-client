//
//  MoPubCustomAdAdapter.h
//  SimpleAds
//
//  Created by Nafis Jamal on 10/25/10.
//  Copyright 2010 Stanford. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MoPubNativeSDKAdapter.h"

@interface MoPubCustomAdAdapter : MoPubNativeSDKAdapter {

}

+ (NSString *)networkType;


@end
