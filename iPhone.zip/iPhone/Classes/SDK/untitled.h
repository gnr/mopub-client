//
//  untitled.h
//  SimpleAds
//
//  Created by Nafis Jamal on 11/27/10.
//  Copyright 2010 Stanford. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface untitled : UIViewController {

}

@end
